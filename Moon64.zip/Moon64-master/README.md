# Render96ex
Fork of [sm64ex](https://github.com/sm64pc/sm64ex)

This is meant to be a fork where the team can upload their code.
If you want to help sm64ex then go to their repo. 
If you want to help us out then message me on discord DorfDork#4516
