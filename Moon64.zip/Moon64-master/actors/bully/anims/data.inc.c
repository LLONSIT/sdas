#include "anim_050042A4.inc.c"
#include "anim_050043D8.inc.c"
#include "anim_05004598.inc.c"
#include "anim_050046F4.inc.c"
