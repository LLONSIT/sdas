// 0x050009E8
const struct Animation *const birds_seg5_anims_050009E8[] = {
    &birds_seg5_anim_050008D0,
    &birds_seg5_anim_050009D0,
};
