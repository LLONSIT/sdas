#include "anim_0801DA34.inc.c"
