#include "anim_060058E0.inc.c"
