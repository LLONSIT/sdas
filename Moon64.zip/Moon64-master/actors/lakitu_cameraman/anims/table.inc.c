// 0x060058F8
const struct Animation *const lakitu_seg6_anims_060058F8[] = {
    &lakitu_seg6_anim_060058E0,
    NULL,
};
