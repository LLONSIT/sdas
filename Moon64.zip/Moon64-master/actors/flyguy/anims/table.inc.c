// 0x08011A64
const struct Animation *const flyguy_seg8_anims_08011A64[] = {
    &flyguy_seg8_anim_08011A4C,
    NULL,
    NULL,
};
