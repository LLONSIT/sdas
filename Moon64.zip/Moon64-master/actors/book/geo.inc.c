// 0x0C0000C0
const GeoLayout bookend_geo[] = {
   GEO_CULLING_RADIUS(300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, book_seg5_dl_05002FB0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
