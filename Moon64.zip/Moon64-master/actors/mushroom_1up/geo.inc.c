// 0x16000E84
const GeoLayout mushroom_1up_geo[] = {
   GEO_SHADOW(SHADOW_CIRCLE_4_VERTS, 0xB4, 80),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, mushroom_1up_seg3_dl_0302A660),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
