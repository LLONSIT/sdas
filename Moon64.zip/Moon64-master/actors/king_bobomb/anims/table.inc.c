// 0x0500FE30
const struct Animation *const king_bobomb_seg5_anims_0500FE30[] = {
    &king_bobomb_seg5_anim_0500BDFC,
    &king_bobomb_seg5_anim_0500C2AC,
    &king_bobomb_seg5_anim_0500C520,
    &king_bobomb_seg5_anim_0500C774,
    &king_bobomb_seg5_anim_0500CFCC,
    &king_bobomb_seg5_anim_0500D5B0,
    &king_bobomb_seg5_anim_0500D978,
    &king_bobomb_seg5_anim_0500DDD8,
    &king_bobomb_seg5_anim_0500E10C,
    &king_bobomb_seg5_anim_0500F078,
    &king_bobomb_seg5_anim_0500F6C8,
    &king_bobomb_seg5_anim_0500FE18,
};
