#include "anim_050079E4.inc.c"
#include "anim_05007DCC.inc.c"
#include "anim_050087C0.inc.c"
#include "anim_05008B5C.inc.c"
