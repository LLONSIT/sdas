// 0x03015458
static const struct Animation door_seg3_anim_03015458 = {
    1,
    0,
    40,
    40,
    0x50,
    ANIMINDEX_NUMPARTS(door_seg3_animindex_03015404),
    door_seg3_animvalue_03015220,
    door_seg3_animindex_03015404,
    0,
};
