// 0x0F0004CC
const GeoLayout purple_switch_geo[] = {
   GEO_CULLING_RADIUS(300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, purple_switch_seg8_dl_0800C718),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
